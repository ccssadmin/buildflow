const Footer = ()=>{  
  return (<>
    {/* <h1 className="foot">Footer</h1> */}
    
    <div className="footer-content">
        Copyright © 2023
        <span className="footer-content__name"> Euroland IR. </span> All rights reserved. Terms &
        Conditions
      </div>
  </>);
}

export default Footer;